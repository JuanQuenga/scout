var upcHighlighter=(function(){"use strict";function v(r){return r}const y={matches:["<all_urls>"],runAt:"document_idle",allFrames:!0,main(){const r=(...t)=>{try{console.log("[Scout UPC Highlighter]",...t)}catch{}},u=/\b(\d{12})\b/g,E=`
      .scout-upc-highlight {
        background-color: rgba(59, 130, 246, 0.15);
        border-bottom: 2px dotted #3b82f6;
        cursor: pointer;
        padding: 1px 2px;
        border-radius: 2px;
        transition: all 0.2s ease;
        position: relative;
      }
      
      .scout-upc-highlight:hover {
        background-color: rgba(59, 130, 246, 0.25);
        border-bottom-style: solid;
      }
      
      .scout-upc-copied {
        background-color: rgba(16, 185, 129, 0.2) !important;
        border-bottom-color: #10b981 !important;
      }
      
      .scout-upc-tooltip {
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        background-color: #1f2937;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 10000;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        margin-bottom: 4px;
      }
      
      .scout-upc-tooltip.show {
        opacity: 1;
      }
      
      .scout-upc-tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border-width: 4px;
        border-style: solid;
        border-color: #1f2937 transparent transparent transparent;
      }
    `,p=document.createElement("style");p.textContent=E,p.id="scout-upc-highlighter-styles",(document.head||document.documentElement).appendChild(p);const h=(t,o)=>{document.querySelectorAll(".scout-upc-tooltip").forEach(n=>{n.remove()});const e=document.createElement("div");e.className="scout-upc-tooltip",e.textContent=o,t.appendChild(e),setTimeout(()=>{e.classList.add("show")},10),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},200)},2e3)},x=async(t,o)=>{try{await navigator.clipboard.writeText(t),o.classList.add("scout-upc-copied"),h(o,"UPC copied!"),setTimeout(()=>{o.classList.remove("scout-upc-copied")},2e3),r("UPC code copied to clipboard:",t)}catch(e){r("Failed to copy UPC code:",e),h(o,"Failed to copy")}},T=t=>{const o=t.textContent;if(!o||!u.test(o))return;const e=document.createDocumentFragment();let n=0,s;for(u.lastIndex=0;(s=u.exec(o))!==null;){s.index>n&&e.appendChild(document.createTextNode(o.substring(n,s.index)));const i=document.createElement("span"),a=s[0];i.className="scout-upc-highlight",i.textContent=a,i.setAttribute("data-upc",a),i.title=`Click to copy UPC: ${a}`,i.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();const l=c.currentTarget.getAttribute("data-upc");x(l,i)}),i.addEventListener("mouseenter",()=>{i.classList.contains("scout-upc-copied")||h(i,"Click to copy UPC")}),e.appendChild(i),n=s.index+s[0].length}n<o.length&&e.appendChild(document.createTextNode(o.substring(n))),e.childNodes.length>0&&t.parentNode.replaceChild(e,t)},g=t=>{if(!(t.nodeType===Node.ELEMENT_NODE&&(t.tagName==="SCRIPT"||t.tagName==="STYLE"||t.tagName==="NOSCRIPT"||t.classList.contains("scout-upc-highlight")))){if(t.nodeType===Node.TEXT_NODE){T(t);return}t.childNodes&&Array.from(t.childNodes).forEach(g)}},m=()=>{document.body&&g(document.body)},N=()=>{const t=new MutationObserver(o=>{o.some(n=>n.type==="childList"&&n.addedNodes.length>0||n.type==="characterData")&&setTimeout(m,100)});return document.body&&t.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),t},f=t=>{const o=window.location.hostname;if(!o||o===""){t(!0);return}try{chrome.runtime.sendMessage({action:"checkSiteStatus",domain:o},e=>{if(chrome.runtime.lastError){r("Error checking site status:",chrome.runtime.lastError),t(!0);return}e&&e.success?t(!e.disabled):t(!0)})}catch(e){r("Failed to check site status:",e),t(!0)}},b=()=>{f(t=>{if(!t){r("UPC highlighting is disabled for this site");return}r("Initializing UPC highlighter"),setTimeout(m,500);const o=N();try{chrome.runtime.onMessage.addListener((e,n,s)=>(e.action==="pm-settings-changed"&&f(i=>{if(i)location.reload();else{document.querySelectorAll(".scout-upc-highlight").forEach(c=>{const l=c.parentNode;l&&l.replaceChild(document.createTextNode(c.textContent),c)});const a=document.getElementById("scout-upc-highlighter-styles");a&&a.remove(),o&&o.disconnect()}}),!0))}catch(e){r("Failed to set up message listener:",e)}})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",b):b()}};function w(){}function d(r,...u){}const C={debug:(...r)=>d(console.debug,...r),log:(...r)=>d(console.log,...r),warn:(...r)=>d(console.warn,...r),error:(...r)=>d(console.error,...r)};return(async()=>{try{return await y.main()}catch(r){throw C.error('The unlisted script "upc-highlighter" crashed on startup!',r),r}})()})();
upcHighlighter;