var ebaySoldSummary=(function(){"use strict";function U(r){return r}const P={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){console.log("🐕 [Scout eBay Sold Summary] SCRIPT LOADED - Version 2");const r="scout-ebay-sold-summary",w="scout-ebay-sold-summary-style";let _=!1;const s=(...t)=>{try{console.log("[Scout eBay Sold Summary]",...t)}catch{}},I=()=>{if(document.getElementById(w))return;const t=document.createElement("style");t.id=w,t.textContent=`
        #${r} {
          width: 100%;
          border: 1px solid #1d4ed8;
          background: rgba(37, 99, 235, 0.08);
          padding: 14px 18px;
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
          position: relative;
        }
        #${r} h2 {
          font-size: 17px;
          margin: 0 0 10px;
          font-weight: 600;
          color: #1e293b;
        }
        #${r} .scout-ebay-summary__metrics {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        #${r} .scout-ebay-summary__metric {
          min-width: 120px;
          background: rgba(255, 255, 255, 0.6);
          padding: 10px 12px;
          border-radius: 8px;
          border: 1px solid rgba(148, 163, 184, 0.4);
        }
        #${r} .scout-ebay-summary__metric strong {
          display: block;
          font-size: 16px;
          margin-bottom: 4px;
        }
        #${r} .scout-ebay-summary__metric-button {
          min-width: 120px;
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(37, 99, 235, 0.95));
          padding: 12px 16px;
          border-radius: 8px;
          border: 1px solid rgba(59, 130, 246, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
          text-align: center;
          color: white;
          font-weight: 600;
          font-size: 13px;
          box-shadow: 0 2px 8px rgba(37, 99, 235, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        #${r} .scout-ebay-summary__metric-button:hover {
          background: linear-gradient(135deg, rgba(37, 99, 235, 1), rgba(29, 78, 216, 1));
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);
          border-color: rgba(29, 78, 216, 0.8);
        }
        #${r} .scout-ebay-summary__metric-button:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(37, 99, 235, 0.3);
        }
        #${r} .scout-ebay-summary__dismiss {
          position: absolute;
          top: 10px;
          right: 10px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
        }
        #${r} .scout-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.9);
          border-color: rgba(220, 38, 38, 0.8);
          color: white;
        }
        #${r} .scout-ebay-summary__meta {
          margin-top: 12px;
          font-size: 12px;
          color: #475569;
        }
      `,document.head.appendChild(t)},S=()=>{try{const t=new URL(window.location.href);if(!/\.ebay\./i.test(t.hostname)||!t.pathname.startsWith("/sch/"))return!1;const e=t.searchParams.get("LH_Sold");return e==="1"||e==="true"}catch{return!1}},k=t=>{if(!t)return null;let e=t.replace(/\(.*?\)/g,"").replace(/Approximately\s+/i,"").replace(/About\s+/i,"").trim();const n=e.split(/\bto\b|-/i);n.length>1&&(e=n[0]);const a=e.match(/[\d,.]+/);if(!a)return null;const i=parseFloat(a[0].replace(/,/g,""));return Number.isFinite(i)?i:null},R=t=>{if(!t)return"$";const e=t.replace(/[\d.,]/g,"").replace(/\s+/g," ").trim();if(e)return e;const n=t.match(/[$\u00a3\u00a5\u20ac]/);return n?n[0]:"$"},b=(t,e)=>{const n=t.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2});return`${e?e+" ":""}${n}`.trim()},T=t=>{try{const e=t.querySelector(".s-item__title--tagblock .POSITIVE")||t.querySelector(".s-item__ended-date");if(!e)return null;const n=e.textContent?.trim();if(!n)return null;const a=n.match(/Sold\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})/i);if(!a)return null;const i=a[1],u=new Date(i);return isNaN(u.getTime())?null:u}catch{return null}},A=()=>{const t=document.querySelector("ul.srp-results.srp-grid")||document.querySelector("#srp-river-results");if(!t)return s("⚠️ Could not find main results container"),{prices:[],currencyPrefix:"$",mostRecentDate:null};s("✓ Found main results container");const e=Array.from(t.children).filter(o=>o.tagName==="LI");s("Found",e.length,"total <li> elements");const n=[];for(let o=0;o<e.length;o++){const l=e[o];if(l.hasAttribute("data-listingid")){n.push(l);continue}const p=l.className||"",y=l.textContent||"";if(p.includes("srp-river-answer--REWRITE_START")||y.includes("Results matching fewer words")){s("🛑 STOP: Found 'fewer words' divider at index",o),s("   - Collected",n.length,"products before divider");break}s("Skipping divider/notice at index",o)}s("✅ Final count:",n.length,"product listings");const a=[],i=[];let u=null;for(const o of n){const l=o.querySelector(".s-card__price")||o.querySelector(".s-item__price")||o.querySelector("[data-test-id='ITEM-PRICE']");if(!l)continue;const p=l.textContent?.trim();if(!p)continue;const y=k(p);if(y===null)continue;u||(u=R(p)),a.push(y);const x=T(o);x&&i.push(x)}s("💰 Extracted",a.length,"prices"),s("📅 Extracted",i.length,"dates");let d=null;return i.length>0&&(d=i.reduce((o,l)=>l>o?l:o)),{prices:a,currencyPrefix:u||"$",mostRecentDate:d}},h=()=>{const t=document.getElementById(r);t&&t.remove()},B=()=>{let t=document.getElementById(r);if(t)return s("✓ Summary container already exists"),t;const e=document.querySelector(".srp-controls__row-2");if(s("Searching for .srp-controls__row-2:",e?"FOUND":"NOT FOUND"),e)return t=document.createElement("section"),t.id=r,e.appendChild(t),s("✓ Summary container inserted into .srp-controls__row-2"),t;const n=document.getElementById("srp-river-results");return s("Fallback: Searching for #srp-river-results:",n?"FOUND":"NOT FOUND"),!n||!n.parentElement?(s("✗ Cannot insert summary - no suitable parent found"),null):(t=document.createElement("section"),t.id=r,n.parentElement.insertBefore(t,n),s("✓ Summary container inserted before #srp-river-results (fallback)"),t)},v=()=>{_=!1,s("=== renderSummary called ===");const t=S();if(s("Is sold results page?",t),!t){h();return}const{prices:e,currencyPrefix:n,mostRecentDate:a}=A();if(s("Collected prices:",e.length,"prices found"),!e.length){s("✗ No prices found, removing summary"),h();return}I();const i=B();if(!i){s("✗ Could not create/find container");return}const u=[...e].sort((c,m)=>c-m),d=e.length,l=e.reduce((c,m)=>c+m,0)/d,p=d%2===1?u[(d-1)/2]:(u[d/2-1]+u[d/2])/2,y=u[0],x=u[u.length-1];let E="N/A";if(a){const c={month:"short",day:"numeric",year:"numeric"};E=a.toLocaleDateString("en-US",c)}i.innerHTML=`
        <button class="scout-ebay-summary__dismiss" title="Dismiss" data-action="dismiss">×</button>
        <h2>Scout Price Summary</h2>
        <div class="scout-ebay-summary__metrics">
          <div class="scout-ebay-summary__metric">
            <strong>Average</strong>
            <span>${b(l,n)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Median</strong>
            <span>${b(p,n)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Highest</strong>
            <span>${b(x,n)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Lowest</strong>
            <span>${b(y,n)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Listings</strong>
            <span>${d}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Latest Sold</strong>
            <span>${E}</span>
          </div>
          <div class="scout-ebay-summary__metric-button" data-action="view-used">
            View Used
          </div>
          <div class="scout-ebay-summary__metric-button" data-action="view-new">
            View New
          </div>
        </div>
        <div class="scout-ebay-summary__meta">
          Based on ${d} sold listings detected on this page. Apply filters or refresh to recalculate.
        </div>
      `;const L=i.querySelector('[data-action="dismiss"]'),D=i.querySelector('[data-action="view-used"]'),C=i.querySelector('[data-action="view-new"]');L&&L.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation(),s("Dismiss button clicked"),h()}),D&&D.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();const m=new URL(window.location.href);m.searchParams.set("LH_ItemCondition","4"),window.location.href=m.toString()}),C&&C.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();const m=new URL(window.location.href);m.searchParams.set("LH_ItemCondition","3"),window.location.href=m.toString()})},g=()=>{if(!_){_=!0;try{window.requestAnimationFrame(v)}catch{setTimeout(v,150)}}},N=new MutationObserver(()=>{if(!S()){h();return}g()}),$=()=>{if(s("=== Scout eBay Sold Summary Starting ==="),s("Current URL:",window.location.href),!document.body){s("Body not ready, retrying..."),setTimeout($,100);return}try{N.observe(document.body,{childList:!0,subtree:!0}),s("✓ Mutation observer started")}catch(t){s("Failed to observe mutations",t)}["pushState","replaceState"].forEach(t=>{try{const e=history[t];if(typeof e!="function")return;history[t]=function(...n){const a=e.apply(this,n);return g(),a}}catch(e){s(`Failed to wrap history.${t}`,e)}}),window.addEventListener("popstate",g),document.addEventListener("visibilitychange",()=>{document.hidden||g()}),g()};$()}};function q(){}function f(r,...w){}const F={debug:(...r)=>f(console.debug,...r),log:(...r)=>f(console.log,...r),warn:(...r)=>f(console.warn,...r),error:(...r)=>f(console.error,...r)};return(async()=>{try{return await P.main()}catch(r){throw F.error('The unlisted script "ebay-sold-summary" crashed on startup!',r),r}})()})();
ebaySoldSummary;