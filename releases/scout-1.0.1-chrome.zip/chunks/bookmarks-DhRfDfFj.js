import{c as d}from"./trending-up-DclccO-R.js";/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",key:"1fy3hk"}]],g=d("bookmark",c);/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],p=d("layers",k);/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]],b=d("search",m);/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],y=d("x",u);function i(e){const t=[];for(const o of e)o.url&&t.push({id:o.id,title:o.title||"Untitled",url:o.url,dateAdded:o.dateAdded}),o.children&&t.push(...i(o.children));return t}async function l(){return new Promise(e=>{chrome.bookmarks.getTree(t=>{if(chrome.runtime.lastError){console.error("[Bookmarks] Error getting bookmarks:",chrome.runtime.lastError),e([]);return}const o=i(t);o.sort((n,a)=>(a.dateAdded||0)-(n.dateAdded||0)),console.log("[Bookmarks] Found bookmarks:",o.length),e(o)})})}async function B(){return new Promise(e=>{chrome.bookmarks.getTree(t=>{if(chrome.runtime.lastError){console.error("[Bookmarks] Error getting folders:",chrome.runtime.lastError),e([]);return}const o=[];function n(a){for(const r of a)!r.url&&r.id!=="0"&&o.push({id:r.id,title:r.title||"Untitled",parentId:r.parentId}),r.children&&n(r.children)}n(t),console.log("[Bookmarks] Found folders:",o.length),e(o)})})}async function f(e,t=!0){return new Promise(o=>{if(!e){l().then(o);return}chrome.bookmarks.getSubTree(e,n=>{if(chrome.runtime.lastError){console.error("[Bookmarks] Error getting folder bookmarks:",chrome.runtime.lastError),o([]);return}const a=t?i(n):n[0]?.children?.filter(r=>r.url).map(r=>({id:r.id,title:r.title||"Untitled",url:r.url,dateAdded:r.dateAdded}))||[];a.sort((r,s)=>(s.dateAdded||0)-(r.dateAdded||0)),console.log(`[Bookmarks] Found ${a.length} bookmarks in folder ${e}`),o(a)})})}async function A(e){if(!e||e.length===0)return l();const t=e.map(r=>f(r,!0)),o=await Promise.all(t),n=new Map;for(const r of o)for(const s of r)n.has(s.id)||n.set(s.id,s);const a=Array.from(n.values());return a.sort((r,s)=>(s.dateAdded||0)-(r.dateAdded||0)),console.log(`[Bookmarks] Found ${a.length} bookmarks from ${e.length} folders`),a}function w(e,t){if(!t.trim())return e;const o=t.toLowerCase();return e.filter(n=>{const a=n.title?.toLowerCase()||"",r=n.url?.toLowerCase()||"";return a.includes(o)||r.includes(o)})}export{g as B,p as L,b as S,y as X,A as a,w as f,B as g};
