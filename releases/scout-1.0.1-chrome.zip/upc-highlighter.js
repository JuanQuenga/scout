var upcHighlighter=(function(){"use strict";function N(n){return n}const b={matches:["<all_urls>"],runAt:"document_idle",allFrames:!0,main(){const n=(...t)=>{try{console.log("[Scout UPC Highlighter]",...t)}catch{}},l=/\b(\d{12})\b/g,y=`
      .scout-upc-highlight {
        background-color: rgba(59, 130, 246, 0.15);
        border-bottom: 2px dotted #3b82f6;
        cursor: pointer;
        padding: 1px 2px;
        border-radius: 2px;
        transition: all 0.2s ease;
        position: relative;
      }

      .scout-upc-highlight:hover {
        background-color: rgba(59, 130, 246, 0.25);
        border-bottom-style: solid;
      }

      .scout-upc-copied {
        background-color: rgba(16, 185, 129, 0.2) !important;
        border-bottom-color: #10b981 !important;
      }

      .scout-upc-tooltip {
        position: fixed;
        background-color: #1f2937;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 2147483647;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      }

      .scout-upc-tooltip.show {
        opacity: 1;
      }
    `,C=()=>{if(!document.getElementById("scout-upc-highlighter-styles")){const t=document.createElement("style");t.textContent=y,t.id="scout-upc-highlighter-styles",(document.head||document.documentElement).appendChild(t)}},h=(t,o)=>{document.querySelectorAll(".scout-upc-tooltip").forEach(d=>{d.remove()});const e=document.createElement("div");e.className="scout-upc-tooltip",e.textContent=o,document.body.appendChild(e);const i=t.getBoundingClientRect(),r=e.getBoundingClientRect();let c=i.left+i.width/2-r.width/2,s=i.top-r.height-8;c<5&&(c=5),c+r.width>window.innerWidth-5&&(c=window.innerWidth-r.width-5),s<5&&(s=i.bottom+8),e.style.left=`${c}px`,e.style.top=`${s}px`,setTimeout(()=>{e.classList.add("show")},10),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},200)},2e3)},E=async(t,o)=>{try{await navigator.clipboard.writeText(t),o.classList.add("scout-upc-copied"),h(o,"UPC copied!"),setTimeout(()=>{o.classList.remove("scout-upc-copied")},2e3),n("UPC code copied to clipboard:",t)}catch(e){n("Failed to copy UPC code:",e),h(o,"Failed to copy")}},w=t=>{const o=t.textContent;if(!o||!l.test(o))return;const e=document.createDocumentFragment();let i=0,r;for(l.lastIndex=0;(r=l.exec(o))!==null;){r.index>i&&e.appendChild(document.createTextNode(o.substring(i,r.index)));const c=document.createElement("span"),s=r[0];c.className="scout-upc-highlight",c.textContent=s,c.setAttribute("data-upc",s),c.title=`Click to copy UPC: ${s}`,c.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation();const u=d.currentTarget.getAttribute("data-upc");E(u,c)}),c.addEventListener("mouseenter",()=>{c.classList.contains("scout-upc-copied")||h(c,"Click to copy UPC")}),e.appendChild(c),i=r.index+r[0].length}i<o.length&&e.appendChild(document.createTextNode(o.substring(i))),e.childNodes.length>0&&t.parentNode.replaceChild(e,t)},p=t=>{if(!(t.nodeType===Node.ELEMENT_NODE&&(t.tagName==="SCRIPT"||t.tagName==="STYLE"||t.tagName==="NOSCRIPT"||t.classList.contains("scout-upc-highlight")))){if(t.nodeType===Node.TEXT_NODE){w(t);return}t.childNodes&&Array.from(t.childNodes).forEach(p)}},g=()=>{document.body&&p(document.body)},x=()=>{const t=new MutationObserver(o=>{o.some(i=>i.type==="childList"&&i.addedNodes.length>0||i.type==="characterData")&&setTimeout(g,100)});return document.body&&t.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),t},T=t=>{try{chrome.storage.sync.get(["cmdkSettings"],o=>{if(chrome.runtime.lastError){n("Error checking settings:",chrome.runtime.lastError),t(!0);return}const i=o.cmdkSettings?.upcHighlighter?.enabled??!0;t(i)})}catch(o){n("Failed to check settings:",o),t(!0)}},m=()=>{T(t=>{if(!t){n("UPC highlighting is disabled in settings");return}window===window.top&&n("Initializing UPC highlighter"),C(),setTimeout(g,500);const o=x();try{chrome.runtime.onMessage.addListener((e,i,r)=>{if(e.action==="upc-highlighter-settings-changed")if(e.enabled??!0)n("UPC highlighting re-enabled, reloading page"),location.reload();else{document.querySelectorAll(".scout-upc-highlight").forEach(d=>{const u=d.parentNode;u&&u.replaceChild(document.createTextNode(d.textContent),d)});const s=document.getElementById("scout-upc-highlighter-styles");s&&s.remove(),o&&o.disconnect(),n("UPC highlighting disabled")}return!0})}catch(e){n("Failed to set up message listener:",e)}})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",m):m()}};function v(){}function a(n,...l){}const f={debug:(...n)=>a(console.debug,...n),log:(...n)=>a(console.log,...n),warn:(...n)=>a(console.warn,...n),error:(...n)=>a(console.error,...n)};return(async()=>{try{return await b.main()}catch(n){throw f.error('The unlisted script "upc-highlighter" crashed on startup!',n),n}})()})();
upcHighlighter;