var ebaySoldSummary=(function(){"use strict";function J(e){return e}const N={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){if(!window.location.hostname.includes("ebay.com")||!window.location.pathname.startsWith("/sch/")){console.log("🐕 [Scout eBay Sold Summary] Not on eBay search page, exiting");return}console.log("🐕 [Scout eBay Sold Summary] SCRIPT LOADED - Version 2");const e="scout-ebay-sold-summary",v="scout-ebay-sold-summary-style";let E=!1,x=!1;const r=(...t)=>{try{console.log("[Scout eBay Sold Summary]",...t)}catch{}},O=()=>{if(document.getElementById(v))return;const t=document.createElement("style");t.id=v,t.textContent=`
        #${e} {
          width: 100%;
          border: 1px solid #1d4ed8;
          background: rgba(37, 99, 235, 0.08);
          padding: 14px 18px;
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
          position: relative;
        }
        #${e} h2 {
          font-size: 17px;
          margin: 0 0 10px;
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #${e} h2 img {
          width: 20px;
          height: 20px;
        }
        #${e} .scout-ebay-summary__metrics {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        #${e} .scout-ebay-summary__metric {
          min-width: 120px;
          background: rgba(255, 255, 255, 0.6);
          padding: 10px 12px;
          border-radius: 8px;
          border: 1px solid rgba(148, 163, 184, 0.4);
        }
        #${e} .scout-ebay-summary__metric--clickable {
          cursor: pointer;
          transition: all 0.2s ease;
        }
        #${e} .scout-ebay-summary__metric--clickable:hover {
          background: rgba(59, 130, 246, 0.15);
          border-color: rgba(59, 130, 246, 0.6);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
        }
        #${e} .scout-ebay-summary__metric--clickable:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(59, 130, 246, 0.3);
        }
        #${e} .scout-ebay-summary__metric strong {
          display: block;
          font-size: 16px;
          margin-bottom: 4px;
        }
        #${e} .scout-ebay-summary__metric-button {
          min-width: 120px;
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(37, 99, 235, 0.95));
          padding: 12px 16px;
          border-radius: 8px;
          border: 1px solid rgba(59, 130, 246, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
          text-align: center;
          color: white;
          font-weight: 600;
          font-size: 13px;
          box-shadow: 0 2px 8px rgba(37, 99, 235, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        #${e} .scout-ebay-summary__metric-button:hover {
          background: linear-gradient(135deg, rgba(37, 99, 235, 1), rgba(29, 78, 216, 1));
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);
          border-color: rgba(29, 78, 216, 0.8);
        }
        #${e} .scout-ebay-summary__metric-button:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(37, 99, 235, 0.3);
        }
        #${e} .scout-ebay-summary__metric-button[disabled] {
          background: rgba(148, 163, 184, 0.3);
          color: rgba(71, 85, 105, 0.6);
          cursor: not-allowed;
          opacity: 0.5;
          pointer-events: none;
        }
        #${e} .scout-ebay-summary__metric-button[disabled]:hover {
          transform: none;
          box-shadow: none;
        }
        #${e} .scout-ebay-summary__dismiss {
          position: absolute;
          top: 10px;
          right: 10px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${e} .scout-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.9);
          border-color: rgba(220, 38, 38, 0.8);
          color: white;
        }
        #${e} .scout-ebay-summary__settings {
          position: absolute;
          top: 10px;
          right: 46px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${e} .scout-ebay-summary__settings:hover {
          background: rgba(59, 130, 246, 0.9);
          border-color: rgba(37, 99, 235, 0.8);
          color: white;
        }
        #${e} .scout-ebay-summary__meta {
          margin-top: 12px;
          font-size: 12px;
          color: #475569;
        }
        .scout-listing-highlight {
          animation: scout-highlight-pulse 1s ease-in-out;
          outline: 3px solid rgba(59, 130, 246, 0.8) !important;
          outline-offset: 4px;
          border-radius: 8px !important;
          background: rgba(59, 130, 246, 0.05) !important;
        }
        @keyframes scout-highlight-pulse {
          0%, 100% {
            outline-color: rgba(59, 130, 246, 0.8);
            outline-width: 3px;
          }
          50% {
            outline-color: rgba(37, 99, 235, 1);
            outline-width: 5px;
          }
        }
      `,document.head.appendChild(t)},L=()=>{try{const t=new URL(window.location.href);if(!/\.ebay\./i.test(t.hostname)||!t.pathname.startsWith("/sch/"))return!1;const n=t.searchParams.get("LH_Sold");return n==="1"||n==="true"}catch{return!1}},z=t=>{if(!t)return null;let n=t.replace(/\(.*?\)/g,"").replace(/Approximately\s+/i,"").replace(/About\s+/i,"").trim();const o=n.split(/\bto\b|-/i);o.length>1&&(n=o[0]);const a=n.match(/[\d,.]+/);if(!a)return null;const d=parseFloat(a[0].replace(/,/g,""));return Number.isFinite(d)?d:null},H=t=>{if(!t)return"$";const n=t.replace(/[\d.,]/g,"").replace(/\s+/g," ").trim();if(n)return n;const o=t.match(/[$\u00a3\u00a5\u20ac]/);return o?o[0]:"$"},w=(t,n)=>{const o=t.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2});return`${n?n+" ":""}${o}`.trim()},Y=t=>{try{const n=t.querySelector(".su-styled-text.positive")||t.querySelector(".s-item__title--tagblock .POSITIVE")||t.querySelector(".s-item__ended-date");if(!n)return null;const o=n.textContent?.trim();if(!o)return null;const a=o.match(/Sold\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})/i);if(!a)return null;const d=a[1],y=new Date(d);return isNaN(y.getTime())?null:y}catch{return null}},V=()=>{const t=document.querySelector("ul.srp-results.srp-grid")||document.querySelector("#srp-river-results");if(!t)return r("⚠️ Could not find main results container"),{prices:[],currencyPrefix:"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};r("✓ Found main results container");const n=Array.from(t.children).filter(i=>i.tagName==="LI");r("Found",n.length,"total <li> elements");const o=[];for(let i=0;i<n.length;i++){const c=n[i];if(c.hasAttribute("data-listingid")){o.push(c);continue}const p=c.className||"",h=c.textContent||"";if(p.includes("srp-river-answer--REWRITE_START")||h.includes("Results matching fewer words")){r("🛑 STOP: Found 'fewer words' divider at index",i),r("   - Collected",o.length,"products before divider");break}r("Skipping divider/notice at index",i)}r("✅ Final count:",o.length,"product listings");const a=[];let d=null;for(const i of o){const c=i.querySelector(".s-card__price")||i.querySelector(".s-item__price")||i.querySelector("[data-test-id='ITEM-PRICE']");if(!c)continue;const p=c.textContent?.trim();if(!p)continue;const h=z(p);if(h===null)continue;d||(d=H(p));const S=Y(i);a.push({value:h,element:i,date:S})}if(r("💰 Extracted",a.length,"prices"),a.length===0)return{prices:[],currencyPrefix:d||"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};const y=a.reduce((i,c)=>c.value<i.value?c:i),k=a.reduce((i,c)=>c.value>i.value?c:i),l=a.filter(i=>i.date!==null);let m=null,g=null;l.length>0&&(m=l.reduce((i,c)=>c.date>i.date?c:i),g=m.date);const C=a.map(i=>i.value);return r("📅 Found",l.length,"dates"),{prices:C,currencyPrefix:d||"$",mostRecentDate:g,minElement:y.element,maxElement:k.element,mostRecentElement:m?.element||null}},b=()=>{const t=document.getElementById(e);t&&t.remove()},W=()=>{let t=document.getElementById(e);if(t)return r("✓ Summary container already exists"),t;const n=document.querySelector(".srp-controls__row-2");if(r("Searching for .srp-controls__row-2:",n?"FOUND":"NOT FOUND"),n)return t=document.createElement("section"),t.id=e,n.appendChild(t),r("✓ Summary container inserted into .srp-controls__row-2"),t;const o=document.getElementById("srp-river-results");return r("Fallback: Searching for #srp-river-results:",o?"FOUND":"NOT FOUND"),!o||!o.parentElement?(r("✗ Cannot insert summary - no suitable parent found"),null):(t=document.createElement("section"),t.id=e,o.parentElement.insertBefore(t,o),r("✓ Summary container inserted before #srp-river-results (fallback)"),t)},D=async()=>{E=!1,r("=== renderSummary called ===");try{if(!((await chrome.storage.sync.get(["cmdkSettings"])).cmdkSettings?.ebaySummary?.enabled??!0)){r("✗ eBay Summary feature is disabled in settings"),b();return}}catch(s){r("⚠️ Failed to check settings, assuming enabled",s)}const t=L();if(r("Is sold results page?",t),!t){b();return}if(x){r("✗ Summary was dismissed by user, not showing"),b();return}const{prices:n,currencyPrefix:o,mostRecentDate:a,minElement:d,maxElement:y,mostRecentElement:k}=V();if(r("Collected prices:",n.length,"prices found"),!n.length){r("✗ No prices found, removing summary"),b();return}O();const l=W();if(!l){r("✗ Could not create/find container");return}const m=[...n].sort((s,u)=>s-u),g=n.length,i=n.reduce((s,u)=>s+u,0)/g,c=g%2===1?m[(g-1)/2]:(m[g/2-1]+m[g/2])/2,p=m[0],h=m[m.length-1];let S="N/A";if(a){const s={month:"short",day:"numeric",year:"numeric"};S=a.toLocaleDateString("en-US",s)}const R=new URL(window.location.href).searchParams.get("LH_ItemCondition"),j=R==="4",Q=R==="3",Z=chrome.runtime.getURL("assets/icons/dog-32.png");l.innerHTML=`
        <button type="button" class="scout-ebay-summary__settings" title="Settings" data-action="settings">⚙</button>
        <button type="button" class="scout-ebay-summary__dismiss" title="Dismiss" data-action="dismiss">×</button>
        <h2><img src="${Z}" alt="Scout" /> Scout Price Summary</h2>
        <div class="scout-ebay-summary__metrics">
          <div class="scout-ebay-summary__metric">
            <strong>Average</strong>
            <span>${w(i,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Median</strong>
            <span>${w(c,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric scout-ebay-summary__metric--clickable" data-scroll-to="highest" title="Click to scroll to listing">
            <strong>Highest</strong>
            <span>${w(h,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric scout-ebay-summary__metric--clickable" data-scroll-to="lowest" title="Click to scroll to listing">
            <strong>Lowest</strong>
            <span>${w(p,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Listings</strong>
            <span>${g}</span>
          </div>
          <div class="scout-ebay-summary__metric scout-ebay-summary__metric--clickable" data-scroll-to="latest" title="Click to scroll to listing">
            <strong>Last Sold</strong>
            <span>${S}</span>
          </div>
          <div class="scout-ebay-summary__metric-button" data-action="view-used" ${j?"disabled":""}>
            View Used
          </div>
          <div class="scout-ebay-summary__metric-button" data-action="view-new" ${Q?"disabled":""}>
            View New
          </div>
        </div>
        <div class="scout-ebay-summary__meta">
          Based on ${g} sold listings detected on this page. Apply filters or refresh to recalculate.
        </div>
      `;const I=l.querySelector('[data-action="settings"]'),B=l.querySelector('[data-action="dismiss"]'),F=l.querySelector('[data-action="view-used"]'),q=l.querySelector('[data-action="view-new"]');I&&I.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),r("Settings button clicked"),chrome.runtime.sendMessage({action:"open-settings",section:"ebay"})}),B&&B.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),r("Dismiss button clicked"),x=!0,b()}),F&&F.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation();const u=new URL(window.location.href);u.searchParams.set("LH_ItemCondition","4"),window.location.href=u.toString()}),q&&q.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation();const u=new URL(window.location.href);u.searchParams.set("LH_ItemCondition","3"),window.location.href=u.toString()});const $=(s,u)=>{if(!s){r(`⚠️ No element found for ${u}`);return}document.querySelectorAll(".scout-listing-highlight").forEach(G=>{G.classList.remove("scout-listing-highlight")}),s.scrollIntoView({behavior:"smooth",block:"center"}),s.classList.add("scout-listing-highlight"),setTimeout(()=>{s.classList.remove("scout-listing-highlight")},3e3),r(`✓ Scrolled to and highlighted ${u}`)},T=l.querySelector('[data-scroll-to="highest"]'),U=l.querySelector('[data-scroll-to="lowest"]'),A=l.querySelector('[data-scroll-to="latest"]');T&&T.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),$(y,"highest price listing")}),U&&U.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),$(d,"lowest price listing")}),A&&A.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),$(k,"most recent listing")})},_=()=>{if(!E){E=!0;try{window.requestAnimationFrame(D)}catch{setTimeout(D,150)}}},P=()=>{if(r("=== Scout eBay Sold Summary Starting ==="),r("Current URL:",window.location.href),r("Is eBay search page:",window.location.pathname.startsWith("/sch/")),r("Is sold results page:",L()),!document.body){r("Body not ready, retrying..."),setTimeout(P,100);return}chrome.runtime.onMessage.addListener(t=>{t.action==="ebay-summary-settings-changed"&&(r("Received settings change message:",t),_())}),["pushState","replaceState"].forEach(t=>{try{const n=history[t];if(typeof n!="function")return;history[t]=function(...o){const a=n.apply(this,o);return x=!1,_(),a}}catch(n){r(`Failed to wrap history.${t}`,n)}}),window.addEventListener("popstate",()=>{x=!1,_()}),setTimeout(()=>{_()},500)};P()}};function K(){}function f(e,...v){}const M={debug:(...e)=>f(console.debug,...e),log:(...e)=>f(console.log,...e),warn:(...e)=>f(console.warn,...e),error:(...e)=>f(console.error,...e)};return(async()=>{try{return await N.main()}catch(e){throw M.error('The unlisted script "ebay-sold-summary" crashed on startup!',e),e}})()})();
ebaySoldSummary;