var ebaySoldSummary=(function(){"use strict";function J(e){return e}const B={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){console.log("🐕 [Scout eBay Sold Summary] SCRIPT LOADED - Version 2");const e="scout-ebay-sold-summary",S="scout-ebay-sold-summary-style";let E=!1,x=!1;const s=(...t)=>{try{console.log("[Scout eBay Sold Summary]",...t)}catch{}},M=()=>{if(document.getElementById(S))return;const t=document.createElement("style");t.id=S,t.textContent=`
        #${e} {
          width: 100%;
          border: 1px solid #1d4ed8;
          background: rgba(37, 99, 235, 0.08);
          padding: 14px 18px;
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08);
          position: relative;
        }
        #${e} h2 {
          font-size: 17px;
          margin: 0 0 10px;
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #${e} h2 img {
          width: 20px;
          height: 20px;
        }
        #${e} .scout-ebay-summary__metrics {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }
        #${e} .scout-ebay-summary__metric {
          min-width: 120px;
          background: rgba(255, 255, 255, 0.6);
          padding: 10px 12px;
          border-radius: 8px;
          border: 1px solid rgba(148, 163, 184, 0.4);
        }
        #${e} .scout-ebay-summary__metric--clickable {
          cursor: pointer;
          transition: all 0.2s ease;
        }
        #${e} .scout-ebay-summary__metric--clickable:hover {
          background: rgba(59, 130, 246, 0.15);
          border-color: rgba(59, 130, 246, 0.6);
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
        }
        #${e} .scout-ebay-summary__metric--clickable:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(59, 130, 246, 0.3);
        }
        #${e} .scout-ebay-summary__metric strong {
          display: block;
          font-size: 16px;
          margin-bottom: 4px;
        }
        #${e} .scout-ebay-summary__metric-button {
          min-width: 120px;
          background: linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(37, 99, 235, 0.95));
          padding: 12px 16px;
          border-radius: 8px;
          border: 1px solid rgba(59, 130, 246, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
          text-align: center;
          color: white;
          font-weight: 600;
          font-size: 13px;
          box-shadow: 0 2px 8px rgba(37, 99, 235, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        #${e} .scout-ebay-summary__metric-button:hover {
          background: linear-gradient(135deg, rgba(37, 99, 235, 1), rgba(29, 78, 216, 1));
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);
          border-color: rgba(29, 78, 216, 0.8);
        }
        #${e} .scout-ebay-summary__metric-button:active {
          transform: translateY(0);
          box-shadow: 0 2px 6px rgba(37, 99, 235, 0.3);
        }
        #${e} .scout-ebay-summary__metric-button[disabled] {
          background: rgba(148, 163, 184, 0.3);
          color: rgba(71, 85, 105, 0.6);
          cursor: not-allowed;
          opacity: 0.5;
          pointer-events: none;
        }
        #${e} .scout-ebay-summary__metric-button[disabled]:hover {
          transform: none;
          box-shadow: none;
        }
        #${e} .scout-ebay-summary__dismiss {
          position: absolute;
          top: 10px;
          right: 10px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${e} .scout-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.9);
          border-color: rgba(220, 38, 38, 0.8);
          color: white;
        }
        #${e} .scout-ebay-summary__settings {
          position: absolute;
          top: 10px;
          right: 46px;
          background: rgba(148, 163, 184, 0.2);
          border: 1px solid rgba(148, 163, 184, 0.4);
          border-radius: 6px;
          width: 28px;
          height: 28px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #475569;
          transition: all 0.2s ease;
          z-index: 10;
          pointer-events: auto;
        }
        #${e} .scout-ebay-summary__settings:hover {
          background: rgba(59, 130, 246, 0.9);
          border-color: rgba(37, 99, 235, 0.8);
          color: white;
        }
        #${e} .scout-ebay-summary__meta {
          margin-top: 12px;
          font-size: 12px;
          color: #475569;
        }
        .scout-listing-highlight {
          animation: scout-highlight-pulse 1s ease-in-out;
          outline: 3px solid rgba(59, 130, 246, 0.8) !important;
          outline-offset: 4px;
          border-radius: 8px !important;
          background: rgba(59, 130, 246, 0.05) !important;
        }
        @keyframes scout-highlight-pulse {
          0%, 100% {
            outline-color: rgba(59, 130, 246, 0.8);
            outline-width: 3px;
          }
          50% {
            outline-color: rgba(37, 99, 235, 1);
            outline-width: 5px;
          }
        }
      `,document.head.appendChild(t)},O=()=>{try{const t=new URL(window.location.href);if(!/\.ebay\./i.test(t.hostname)||!t.pathname.startsWith("/sch/"))return!1;const r=t.searchParams.get("LH_Sold");return r==="1"||r==="true"}catch{return!1}},z=t=>{if(!t)return null;let r=t.replace(/\(.*?\)/g,"").replace(/Approximately\s+/i,"").replace(/About\s+/i,"").trim();const o=r.split(/\bto\b|-/i);o.length>1&&(r=o[0]);const a=r.match(/[\d,.]+/);if(!a)return null;const d=parseFloat(a[0].replace(/,/g,""));return Number.isFinite(d)?d:null},H=t=>{if(!t)return"$";const r=t.replace(/[\d.,]/g,"").replace(/\s+/g," ").trim();if(r)return r;const o=t.match(/[$\u00a3\u00a5\u20ac]/);return o?o[0]:"$"},_=(t,r)=>{const o=t.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2});return`${r?r+" ":""}${o}`.trim()},Y=t=>{try{const r=t.querySelector(".su-styled-text.positive")||t.querySelector(".s-item__title--tagblock .POSITIVE")||t.querySelector(".s-item__ended-date");if(!r)return null;const o=r.textContent?.trim();if(!o)return null;const a=o.match(/Sold\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})/i);if(!a)return null;const d=a[1],y=new Date(d);return isNaN(y.getTime())?null:y}catch{return null}},V=()=>{const t=document.querySelector("ul.srp-results.srp-grid")||document.querySelector("#srp-river-results");if(!t)return s("⚠️ Could not find main results container"),{prices:[],currencyPrefix:"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};s("✓ Found main results container");const r=Array.from(t.children).filter(i=>i.tagName==="LI");s("Found",r.length,"total <li> elements");const o=[];for(let i=0;i<r.length;i++){const c=r[i];if(c.hasAttribute("data-listingid")){o.push(c);continue}const p=c.className||"",b=c.textContent||"";if(p.includes("srp-river-answer--REWRITE_START")||b.includes("Results matching fewer words")){s("🛑 STOP: Found 'fewer words' divider at index",i),s("   - Collected",o.length,"products before divider");break}s("Skipping divider/notice at index",i)}s("✅ Final count:",o.length,"product listings");const a=[];let d=null;for(const i of o){const c=i.querySelector(".s-card__price")||i.querySelector(".s-item__price")||i.querySelector("[data-test-id='ITEM-PRICE']");if(!c)continue;const p=c.textContent?.trim();if(!p)continue;const b=z(p);if(b===null)continue;d||(d=H(p));const v=Y(i);a.push({value:b,element:i,date:v})}if(s("💰 Extracted",a.length,"prices"),a.length===0)return{prices:[],currencyPrefix:d||"$",mostRecentDate:null,minElement:null,maxElement:null,mostRecentElement:null};const y=a.reduce((i,c)=>c.value<i.value?c:i),k=a.reduce((i,c)=>c.value>i.value?c:i),l=a.filter(i=>i.date!==null);let m=null,g=null;l.length>0&&(m=l.reduce((i,c)=>c.date>i.date?c:i),g=m.date);const P=a.map(i=>i.value);return s("📅 Found",l.length,"dates"),{prices:P,currencyPrefix:d||"$",mostRecentDate:g,minElement:y.element,maxElement:k.element,mostRecentElement:m?.element||null}},h=()=>{const t=document.getElementById(e);t&&t.remove()},j=()=>{let t=document.getElementById(e);if(t)return s("✓ Summary container already exists"),t;const r=document.querySelector(".srp-controls__row-2");if(s("Searching for .srp-controls__row-2:",r?"FOUND":"NOT FOUND"),r)return t=document.createElement("section"),t.id=e,r.appendChild(t),s("✓ Summary container inserted into .srp-controls__row-2"),t;const o=document.getElementById("srp-river-results");return s("Fallback: Searching for #srp-river-results:",o?"FOUND":"NOT FOUND"),!o||!o.parentElement?(s("✗ Cannot insert summary - no suitable parent found"),null):(t=document.createElement("section"),t.id=e,o.parentElement.insertBefore(t,o),s("✓ Summary container inserted before #srp-river-results (fallback)"),t)},L=async()=>{E=!1,s("=== renderSummary called ===");try{if(!((await chrome.storage.sync.get(["cmdkSettings"])).cmdkSettings?.ebaySummary?.enabled??!0)){s("✗ eBay Summary feature is disabled in settings"),h();return}}catch(n){s("⚠️ Failed to check settings, assuming enabled",n)}const t=O();if(s("Is sold results page?",t),!t){h();return}if(x){s("✗ Summary was dismissed by user, not showing"),h();return}const{prices:r,currencyPrefix:o,mostRecentDate:a,minElement:d,maxElement:y,mostRecentElement:k}=V();if(s("Collected prices:",r.length,"prices found"),!r.length){s("✗ No prices found, removing summary"),h();return}M();const l=j();if(!l){s("✗ Could not create/find container");return}const m=[...r].sort((n,u)=>n-u),g=r.length,i=r.reduce((n,u)=>n+u,0)/g,c=g%2===1?m[(g-1)/2]:(m[g/2-1]+m[g/2])/2,p=m[0],b=m[m.length-1];let v="N/A";if(a){const n={month:"short",day:"numeric",year:"numeric"};v=a.toLocaleDateString("en-US",n)}const C=new URL(window.location.href).searchParams.get("LH_ItemCondition"),W=C==="4",Q=C==="3",Z=chrome.runtime.getURL("assets/icons/dog-32.png");l.innerHTML=`
        <button type="button" class="scout-ebay-summary__settings" title="Settings" data-action="settings">⚙</button>
        <button type="button" class="scout-ebay-summary__dismiss" title="Dismiss" data-action="dismiss">×</button>
        <h2><img src="${Z}" alt="Scout" /> Scout Price Summary</h2>
        <div class="scout-ebay-summary__metrics">
          <div class="scout-ebay-summary__metric">
            <strong>Average</strong>
            <span>${_(i,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Median</strong>
            <span>${_(c,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric scout-ebay-summary__metric--clickable" data-scroll-to="highest" title="Click to scroll to listing">
            <strong>Highest</strong>
            <span>${_(b,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric scout-ebay-summary__metric--clickable" data-scroll-to="lowest" title="Click to scroll to listing">
            <strong>Lowest</strong>
            <span>${_(p,o)}</span>
          </div>
          <div class="scout-ebay-summary__metric">
            <strong>Listings</strong>
            <span>${g}</span>
          </div>
          <div class="scout-ebay-summary__metric scout-ebay-summary__metric--clickable" data-scroll-to="latest" title="Click to scroll to listing">
            <strong>Last Sold</strong>
            <span>${v}</span>
          </div>
          <div class="scout-ebay-summary__metric-button" data-action="view-used" ${W?"disabled":""}>
            View Used
          </div>
          <div class="scout-ebay-summary__metric-button" data-action="view-new" ${Q?"disabled":""}>
            View New
          </div>
        </div>
        <div class="scout-ebay-summary__meta">
          Based on ${g} sold listings detected on this page. Apply filters or refresh to recalculate.
        </div>
      `;const R=l.querySelector('[data-action="settings"]'),I=l.querySelector('[data-action="dismiss"]'),F=l.querySelector('[data-action="view-used"]'),q=l.querySelector('[data-action="view-new"]');R&&R.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),s("Settings button clicked"),chrome.runtime.sendMessage({action:"open-settings",section:"ebay"})}),I&&I.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),s("Dismiss button clicked"),x=!0,h()}),F&&F.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation();const u=new URL(window.location.href);u.searchParams.set("LH_ItemCondition","4"),window.location.href=u.toString()}),q&&q.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation();const u=new URL(window.location.href);u.searchParams.set("LH_ItemCondition","3"),window.location.href=u.toString()});const $=(n,u)=>{if(!n){s(`⚠️ No element found for ${u}`);return}document.querySelectorAll(".scout-listing-highlight").forEach(G=>{G.classList.remove("scout-listing-highlight")}),n.scrollIntoView({behavior:"smooth",block:"center"}),n.classList.add("scout-listing-highlight"),setTimeout(()=>{n.classList.remove("scout-listing-highlight")},3e3),s(`✓ Scrolled to and highlighted ${u}`)},T=l.querySelector('[data-scroll-to="highest"]'),U=l.querySelector('[data-scroll-to="lowest"]'),A=l.querySelector('[data-scroll-to="latest"]');T&&T.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),$(y,"highest price listing")}),U&&U.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),$(d,"lowest price listing")}),A&&A.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),$(k,"most recent listing")})},w=()=>{if(!E){E=!0;try{window.requestAnimationFrame(L)}catch{setTimeout(L,150)}}},D=()=>{if(s("=== Scout eBay Sold Summary Starting ==="),s("Current URL:",window.location.href),!document.body){s("Body not ready, retrying..."),setTimeout(D,100);return}chrome.runtime.onMessage.addListener(t=>{t.action==="ebay-summary-settings-changed"&&(s("Received settings change message:",t),w())}),["pushState","replaceState"].forEach(t=>{try{const r=history[t];if(typeof r!="function")return;history[t]=function(...o){const a=r.apply(this,o);return x=!1,w(),a}}catch(r){s(`Failed to wrap history.${t}`,r)}}),window.addEventListener("popstate",()=>{x=!1,w()}),setTimeout(()=>{w()},500)};D()}};function K(){}function f(e,...S){}const N={debug:(...e)=>f(console.debug,...e),log:(...e)=>f(console.log,...e),warn:(...e)=>f(console.warn,...e),error:(...e)=>f(console.error,...e)};return(async()=>{try{return await B.main()}catch(e){throw N.error('The unlisted script "ebay-sold-summary" crashed on startup!',e),e}})()})();
ebaySoldSummary;