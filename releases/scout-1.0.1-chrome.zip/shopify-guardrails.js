var shopifyGuardrails=(function(){"use strict";function j(e){return e}const T={1e3:"New",1500:"New other (see details)",1750:"New with defects",2e3:"Certified Refurbished",2010:"Excellent - Refurbished",2020:"Very Good - Refurbished",2030:"Good - Refurbished",2500:"Seller refurbished",2750:"Like New",2990:"Pre-owned - Excellent",3e3:"Used",3010:"Pre-owned - Fair",4e3:"Very Good",5e3:"Good",6e3:"Acceptable",7e3:"For Parts (not working)"},v={New:[1e3,1500,1750],new:[1e3,1500,1750],"New other":[1500],"new other":[1500],"New other (see details)":[1500],"new other (see details)":[1500],"New with defects":[1750],"new with defects":[1750],Refurbished:[2e3,2010,2020,2030,2500],refurbished:[2e3,2010,2020,2030,2500],"Certified Refurbished":[2e3],"certified refurbished":[2e3],Used:[2750,2990,3e3,3010,4e3,5e3,6e3],used:[2750,2990,3e3,3010,4e3,5e3,6e3],"Pre-owned":[2750,2990,3e3,3010,4e3,5e3,6e3],"pre-owned":[2750,2990,3e3,3010,4e3,5e3,6e3],"Like New":[2750],"like new":[2750],Damaged:[7e3],damaged:[7e3],"For parts":[7e3],"for parts":[7e3],"For Parts (not working)":[7e3],"for parts (not working)":[7e3],"For parts or not working":[7e3],"for parts or not working":[7e3]};function A(e,h){const f=e?.toLowerCase().trim();for(const[u,d]of Object.entries(v))if(u.toLowerCase()===f)return d.includes(h);return f.includes("refurbish")?v.Refurbished.includes(h):f.includes("new")?v.New.includes(h):f.includes("used")||f.includes("pre-owned")?v.Used.includes(h):f.includes("parts")||f.includes("damaged")?v.Damaged.includes(h):!1}const O={matches:["https://admin.shopify.com/*","https://*.myshopify.com/admin/*"],runAt:"document_idle",allFrames:!1,main(){const e=(...t)=>{try{console.log("[Scout Shopify Guardrails]",...t)}catch{}},h=`
      /* Page border outline */
      .scout-page-outline {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
        border: 5px solid transparent;
        z-index: 999999;
      }

      .scout-page-outline.scout-outline-danger {
        border-color: #ef4444;
        animation: scout-outline-pulse-red 2s ease-in-out infinite;
      }

      .scout-page-outline.scout-outline-warning {
        border-color: #f59e0b;
        animation: scout-outline-pulse-orange 2s ease-in-out infinite;
      }

      @keyframes scout-outline-pulse-red {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
      }

      @keyframes scout-outline-pulse-orange {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
      }

      /* Notification container */
      .scout-notification-container {
        position: fixed;
        top: 80px;
        right: 20px;
        z-index: 10000;
        max-width: 450px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }

      .scout-notification {
        border-radius: 8px;
        padding: 16px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        margin-bottom: 12px;
        animation: scout-slide-in 0.3s ease-out;
      }

      @keyframes scout-slide-in {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }

      .scout-notification-danger {
        background-color: #fef2f2;
        border: 2px solid #ef4444;
      }

      .scout-notification-warning {
        background-color: #fffbeb;
        border: 2px solid #f59e0b;
      }

      .scout-notification-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 12px;
        font-weight: 600;
        font-size: 15px;
      }

      .scout-notification-danger .scout-notification-header {
        color: #991b1b;
      }

      .scout-notification-warning .scout-notification-header {
        color: #92400e;
      }

      .scout-notification-icon {
        width: 20px;
        height: 20px;
        flex-shrink: 0;
      }

      .scout-notification-danger .scout-notification-icon {
        fill: #ef4444;
      }

      .scout-notification-warning .scout-notification-icon {
        fill: #f59e0b;
      }

      .scout-notification-body {
        font-size: 14px;
        line-height: 1.6;
      }

      .scout-notification-danger .scout-notification-body {
        color: #7f1d1d;
      }

      .scout-notification-warning .scout-notification-body {
        color: #92400e;
      }

      .scout-notification-body.scout-clickable {
        cursor: pointer;
        transition: background-color 0.2s;
      }

      .scout-notification-body.scout-clickable:hover {
        background-color: rgba(0, 0, 0, 0.03);
        border-radius: 4px;
        padding: 4px;
        margin: -4px;
      }

      .scout-notification-close {
        background: none;
        border: none;
        cursor: pointer;
        padding: 4px;
        margin-left: auto;
        opacity: 0.7;
        transition: opacity 0.2s;
        font-size: 20px;
        line-height: 1;
      }

      .scout-notification-close:hover {
        opacity: 1;
      }

      .scout-mapping-list {
        margin: 12px 0;
        padding: 8px 12px;
        background-color: rgba(0, 0, 0, 0.05);
        border-radius: 4px;
        max-height: 200px;
        overflow-y: auto;
        font-size: 12px;
        font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
      }

      .scout-mapping-list ul {
        margin: 0;
        padding-left: 20px;
        list-style: none;
      }

      .scout-mapping-list li {
        padding: 2px 0;
      }

      .scout-mapping-list strong {
        color: #1f2937;
        min-width: 50px;
        display: inline-block;
      }

      .scout-highlight-flash {
        animation: scout-highlight-flash 0.6s ease-out;
      }

      @keyframes scout-highlight-flash {
        0% { background-color: rgba(245, 158, 11, 0); }
        50% { background-color: rgba(245, 158, 11, 0.3); }
        100% { background-color: rgba(245, 158, 11, 0); }
      }
    `,f=document.createElement("style");f.textContent=h,f.id="scout-shopify-guardrails-styles",(document.head||document.documentElement).appendChild(f);let u=null,d=null,x=[],b=null;const C=new Map;let L=!1,F=!1,k={enableConditionCheck:!0,enableGoogleFieldsCheck:!0};const $=()=>{try{chrome.storage.sync.get(["cmdkSettings"],t=>{t.cmdkSettings?.shopifyGuardrails&&(k={enableConditionCheck:t.cmdkSettings.shopifyGuardrails.enableConditionCheck??!0,enableGoogleFieldsCheck:t.cmdkSettings.shopifyGuardrails.enableGoogleFieldsCheck??!0},e("Loaded guardrail settings:",k),w())})}catch(t){e("Failed to load settings:",t)}},N=t=>{let o=document.getElementById("scout-page-outline");if(!t){o?.remove();return}!o&&document.body&&(o=document.createElement("div"),o.id="scout-page-outline",o.classList.add("scout-page-outline"),document.body.appendChild(o)),o&&(o.classList.remove("scout-outline-danger","scout-outline-warning"),t==="danger"?(o.classList.add("scout-outline-danger"),e("Applied RED page border (condition mismatch)")):t==="warning"&&(o.classList.add("scout-outline-warning"),e("Applied ORANGE page border (empty Google fields)")))},S=()=>{const t=document.querySelector('[id*="metafields.custom.condition-anchor"]');if(t){e("Found condition container");const o=t.querySelectorAll('[class*="_ReadField_"]');for(const i of o){const n=i.className||"",a=n.includes("_ReadField--placeholder"),c=i.textContent?.trim()||"";if(e("Checking ReadField:",{className:n,isPlaceholder:a,value:c}),!a&&c)return u={element:i,value:c},e("✓ Found Condition field:",u.value),!0}e("✗ No valid condition field found (all fields empty or placeholder)")}else e("✗ Condition container not found");return!1},G=()=>{const t=document.querySelector('[id*="metafields.custom.ebay_condition-anchor"]');if(t){e("Found eBay condition container");const o=t.querySelectorAll('[class*="_ReadField_"]');for(const i of o){const n=i.className||"",a=n.includes("_ReadField--placeholder"),c=i.textContent?.trim()||"";if(e("Checking ReadField:",{className:n,isPlaceholder:a,value:c}),!a&&c){const l=parseInt(c,10);return d={element:i,value:c,id:l},e("✓ Found eBay Condition field:",d.value,"ID:",l),isNaN(l)&&e("⚠️ Warning: eBay condition ID is not a valid number:",c),!0}}e("✗ No valid eBay condition field found (all fields empty or placeholder)")}else e("✗ eBay condition container not found");return!1},I=()=>{x=[];const t=['[id*="metafields.mm-google-shopping"]','[id*="metafields.custom.google"]'];for(const i of t){const n=document.querySelectorAll(i);for(const a of n){const l=a.querySelector("label")?.textContent?.trim()||"";if(l.includes("Google:")||a.id.includes("mm-google-shopping")){const s=a.querySelector('[class*="_ReadField_"]');if(s){const p=s.textContent?.trim()||"";!p||s.classList.contains("_ReadField--placeholder")?(x.push({element:s,label:l,isEmpty:!0}),e("Found EMPTY Google field:",l)):e("Found FILLED Google field:",l,"=",p)}}}}const o=x.filter(i=>i.isEmpty).length;return e(`Found ${o} empty Google fields out of ${x.length} total`),o>0},H=()=>{if(e("=== Checking conditions ==="),!u||!d)return e("✗ Missing condition fields:",{hasConditionField:!!u,hasEbayConditionField:!!d}),null;const t=u.value,o=d.id;if(e("Extracted values:",{shopifyCondition:t,ebayConditionId:o,shopifyConditionType:typeof t,ebayConditionIdType:typeof o}),!t||isNaN(o))return e("✗ Invalid condition values:",{shopifyCondition:t||"(empty)",shopifyConditionValid:!!t,ebayConditionId:o,ebayConditionIdValid:!isNaN(o)}),null;const i=A(t,o);return e(i?"✓":"✗","Condition check result:",{shopify:t,ebayId:o,ebayName:T[o]||"(unknown)",matches:i}),i},R=t=>{if(!t)return;const o=t.element||t;try{o.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"}),o.classList.add("scout-highlight-flash"),setTimeout(()=>{o.classList.remove("scout-highlight-flash")},700),e("Scrolled to element")}catch(i){e("Error scrolling:",i)}},V=()=>{b||(b=document.createElement("div"),b.className="scout-notification-container",document.body.appendChild(b))},m=t=>{if(!C.has(t))return;C.get(t).remove(),C.delete(t),C.size===0&&b&&(b.remove(),b=null)},D=(t,o)=>{if(C.has(t)){const n=C.get(t),a=JSON.stringify(o);if(n.dataset.dataHash===a)return;m(t)}V();const i=document.createElement("div");if(i.className="scout-notification",i.dataset.dataHash=JSON.stringify(o),t==="condition-mismatch"){i.classList.add("scout-notification-danger");const n=document.createElement("div");n.className="scout-notification-header";const a=document.createElementNS("http://www.w3.org/2000/svg","svg");a.setAttribute("class","scout-notification-icon"),a.setAttribute("viewBox","0 0 20 20"),a.innerHTML='<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>';const c=document.createElement("span");c.textContent="Condition Mismatch!";const l=document.createElement("button");l.className="scout-notification-close",l.innerHTML="&times;",l.addEventListener("click",()=>m(t)),n.appendChild(a),n.appendChild(c),n.appendChild(l);const s=document.createElement("div");s.className="scout-notification-body";const p={1e3:"New",1500:"New Other",2750:"Like New",3e3:"Used",4e3:"Very Good",5e3:"Good",6e3:"Acceptable",7e3:"For Parts (not working)"},y=Object.entries(p).map(([z,U])=>{const Y=["2750","4000","5000","6000"].includes(z)?' <em style="color: #7c2d12;">(Video Games Only)</em>':"";return`<li><strong>${z}:</strong> ${U}${Y}</li>`}).join(""),r=document.createElement("div");r.className="scout-clickable",r.innerHTML=`
          <p><strong>The eBay condition doesn't match the Shopify condition!</strong></p>
          <p>Shopify Condition: <strong>${o.shopifyCondition}</strong></p>
          <p>eBay Condition ID: <strong>${o.ebayConditionId}</strong> (${p[o.ebayConditionId]||T[o.ebayConditionId]||"Unknown"})</p>
          <div class="scout-mapping-list">
            <strong>eBay Condition ID Mappings:</strong>
            <ul>${y}</ul>
          </div>
          <p style="font-style: italic; font-size: 12px; margin-top: 8px;">💡 Click to scroll to eBay condition field</p>
        `,r.addEventListener("click",()=>{R(d)});const g=document.createElement("button");g.textContent="Dismiss",g.style.cssText=`
          margin-top: 12px;
          padding: 6px 12px;
          background-color: #ef4444;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 500;
          width: 100%;
          transition: background-color 0.2s;
        `,g.addEventListener("mouseenter",()=>{g.style.backgroundColor="#dc2626"}),g.addEventListener("mouseleave",()=>{g.style.backgroundColor="#ef4444"}),g.addEventListener("click",()=>{F=!0,m(t),N(null),e("✓ Condition mismatch warning dismissed until page refresh")}),s.appendChild(r),s.appendChild(g),i.appendChild(n),i.appendChild(s)}else if(t==="google-fields"){i.classList.add("scout-notification-warning");const n=document.createElement("div");n.className="scout-notification-header";const a=document.createElementNS("http://www.w3.org/2000/svg","svg");a.setAttribute("class","scout-notification-icon"),a.setAttribute("viewBox","0 0 20 20"),a.innerHTML='<path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>';const c=document.createElement("span");c.textContent="Empty Google Fields";const l=document.createElement("button");l.className="scout-notification-close",l.innerHTML="&times;",l.addEventListener("click",()=>m(t)),n.appendChild(a),n.appendChild(c),n.appendChild(l);const s=document.createElement("div");s.className="scout-notification-body";const p=o.fields.map(g=>`<li>${g.label}</li>`).join(""),y=document.createElement("div");y.className="scout-clickable",y.innerHTML=`
          <p><strong>Found ${o.count} empty Google Shopping field(s):</strong></p>
          <ul style="margin: 8px 0; padding-left: 20px;">${p}</ul>
          <p>Please fill these fields to ensure complete Google Shopping data.</p>
          <p style="font-style: italic; font-size: 12px; margin-top: 8px;">💡 Click to scroll to first empty field</p>
        `,y.addEventListener("click",()=>{o.fields.length>0&&R(o.fields[0])});const r=document.createElement("button");r.textContent="Dismiss",r.style.cssText=`
          margin-top: 12px;
          padding: 6px 12px;
          background-color: #f59e0b;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 13px;
          font-weight: 500;
          width: 100%;
          transition: background-color 0.2s;
        `,r.addEventListener("mouseenter",()=>{r.style.backgroundColor="#d97706"}),r.addEventListener("mouseleave",()=>{r.style.backgroundColor="#f59e0b"}),r.addEventListener("click",()=>{L=!0,m(t),N(null),e("✓ Google fields warning dismissed until page refresh")}),s.appendChild(y),s.appendChild(r),i.appendChild(n),i.appendChild(s)}b.appendChild(i),C.set(t,i),e("✓ Notification displayed:",t)},w=()=>{e("=== Performing all checks ==="),u||S(),d||G();const t=k.enableConditionCheck?H():null,o=k.enableGoogleFieldsCheck?I():!1;let i=null;if(k.enableConditionCheck&&t===!1&&!F?(i="danger",D("condition-mismatch",{shopifyCondition:u.value,ebayConditionId:d.id})):m("condition-mismatch"),k.enableGoogleFieldsCheck&&o&&!L){i||(i="warning");const n=x.filter(a=>a.isEmpty);D("google-fields",{count:n.length,fields:n})}else m("google-fields");N(i)};let M=null;const B=(t=100)=>{M&&clearTimeout(M),M=setTimeout(w,t)},q=()=>{const t=new MutationObserver(o=>{let i=!1,n=!1,a=!1,c=!1;for(const l of o){let s=l.target;if(s.nodeType===Node.TEXT_NODE&&(s=s.parentElement),!s||!s.closest)continue;const p=s.closest('[id*="metafields.custom.condition-anchor"]');p&&!p.id.includes("ebay_condition")&&(n=!0,e("🔄 Detected Condition field change:",l.type),i=!0),s.closest('[id*="metafields.custom.ebay_condition-anchor"]')&&(a=!0,e("🔄 Detected eBay Condition field change:",l.type),i=!0),(s.closest('[id*="metafields.custom.google"]')||s.closest('[id*="metafields.mm-google-shopping"]'))&&(c=!0,e("🔄 Detected Google field change:",l.type),i=!0),s.className&&typeof s.className=="string"&&s.className.includes("_ReadField")&&(e("🔄 Detected ReadField change:",l.type,s.className),i=!0)}i&&(n&&(e("Resetting condition field cache"),u=null,F=!1),a&&(e("Resetting eBay condition field cache"),d=null,F=!1),c&&(L=!1),B(150))});return document.body&&(t.observe(document.body,{childList:!0,subtree:!0,characterData:!0,characterDataOldValue:!0,attributes:!0,attributeFilter:["class"]}),e("✓ Mutation observer set up")),t},_=()=>{e("Initializing Shopify Guardrails"),setTimeout(()=>{S(),G(),I(),w()},1e3),q(),document.addEventListener("visibilitychange",()=>{document.hidden||(e("Tab became visible, rechecking..."),B(500))}),setInterval(()=>{document.hidden||w()},1e4);try{chrome.runtime.onMessage.addListener(n=>(n.action==="pm-settings-changed"||n.action==="recheck-conditions"?w():n.action==="guardrails-settings-changed"&&(e("Received settings update:",n.settings),k={enableConditionCheck:n.settings.enableConditionCheck??!0,enableGoogleFieldsCheck:n.settings.enableGoogleFieldsCheck??!0},m("condition-mismatch"),m("google-fields"),N(null),w()),!0))}catch(n){e("Failed to set up message listener:",n)}$();let t=0;const o=15,i=setInterval(()=>{if(u&&d){clearInterval(i);return}if(t++,t>=o){clearInterval(i),e("Stopped retrying after 30 seconds");return}e(`Retry ${t}: Looking for fields...`),u||S(),d||G(),u&&d&&(e("Found all fields on retry!"),w(),clearInterval(i))},2e3)};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",_):_()}};function X(){}function E(e,...h){}const P={debug:(...e)=>E(console.debug,...e),log:(...e)=>E(console.log,...e),warn:(...e)=>E(console.warn,...e),error:(...e)=>E(console.error,...e)};return(async()=>{try{return await O.main()}catch(e){throw P.error('The unlisted script "shopify-guardrails" crashed on startup!',e),e}})()})();
shopifyGuardrails;